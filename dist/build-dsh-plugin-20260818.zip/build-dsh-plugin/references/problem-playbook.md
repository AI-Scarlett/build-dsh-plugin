# DSH problem and solution playbook

## Contents

1. Host and architecture
2. Profile and lifecycle
3. Packaging and release
4. Runtime and UI
5. External integrations
6. Tests, docs, and status

## 1. Host and architecture

For every row, do not copy the solution blindly. First state the control objective, then evaluate the solution's benefit and cost against the current DSH version. Use [decision-guide.md](decision-guide.md) for the full decision record.

| Symptom | Control objective | Root cause / why | Solution | Benefit | Cost / disadvantage | Prevention/evidence |
| --- | --- | --- | --- | --- | --- | --- |
| A requested project cannot load through `dsh plugin add` | Prevent wrong-host installation | It targets Obsidian, VS Code, a browser, desktop, or MCP-only host | Stop; explain mismatch; offer native-host install or a deliberate adapter | Avoids wasted work and unsafe package attempts | May end without an implementation; adapter adds a second contract | Prove `dsh.bundle.patch` and public Host seam before coding |
| Work drifts into an adjacent plugin | Preserve user intent and authorization | Mismatch was discovered but scope was not stopped | Return to requested outcome and ask before expanding scope | Keeps evidence relevant and scope accountable | Pauses momentum and may require a new task | Final status names original target and whether achieved |
| A plan/static mock is called implemented | Keep claims aligned to evidence | No real repository, bundle, or runtime proof exists | Mark `E0/E1`; create the real project before claiming completion | Makes next gate explicit | Status sounds less impressive and requires more work | Evidence ladder in every handoff |
| Plugin proposal becomes a desktop app | Keep DSH lifecycle and distribution standard | Product shape preceded host-contract analysis | Use Host Plugin + optional Client Bundle; external UI only when required | Smaller install/update surface | DSH UI seams may constrain UX | Host-fit record and non-goals |
| Browser bundle fails or leaks privilege | Keep browser side unprivileged | Client imports Host/Node modules | Move privileged work to narrow Host APIs; Client projects safe data | Reduces leakage and attack surface | Requires schemas, API, loading/error states | Contract test scans Client imports and forbidden fields |
| Headless startup fails when UI is absent | Preserve non-Web boot | `webServer` was treated as mandatory/eager | Register with `ctx.inject(['webServer'], ...)` and dispose cleanly | Works across more Profiles | Adds lifecycle complexity and two fixture types | Start Web and no-Web fixtures |
| Required capability seems to need DSH core edits | Preserve official ownership and upgrades | Public seam was not inspected or does not exist | Inspect exact version; use public seam or propose adapter/upstream change | Avoids brittle internal coupling | Capability may be deferred or reduced | Record API seam and DSH commit/version |

## 2. Profile and lifecycle

| Symptom | Control objective | Root cause / why | Solution | Benefit | Cost / disadvantage | Prevention/evidence |
| --- | --- | --- | --- | --- | --- | --- |
| Patch silently removes required config | Preserve complete effective row | Patch rows replace full `config`, not deep-merge | Restate every required key/expression or insert a unique row | Deterministic composition | Overrides are verbose and coupled to inspected schema | `--dump-config` diff and startup smoke |
| Install/update works but restart fails | Make lifecycle atomic end to end | Dependency state and effective bundles differ | Back up, official CLI, dump config, ID checks, restart, readback | Finds semantic failure before declaring success | Longer operation and possible downtime | Transaction test plus Boot ID/health evidence |
| Existing local dependencies become accidental bundles | Preserve unrelated user state | CLI reconciles bundle-declaring dependencies | Inspect before/after bundles; preserve unrelated dependencies and patch bytes | Prevents surprise activation | Requires exact state capture and reconciliation | Pre/post hashes and bundle list |
| Duplicate entry ID breaks cold start | Prevent composition conflicts | Two layers insert the same ID | Scan every Bundle/Profile entry before stopping Host | Fails safely while current Host still runs | Requires whole-composition visibility | Cold-start conflict test; fail before restart |
| Host kills itself and cannot finish restart | Keep restart controller alive | Controller runs inside terminated process | Use approved external supervisor/Guardian with fixed argv | Observable recovery and bounded retry | Adds a component and security/lifecycle work | Stable Boot ID, heartbeat, retry/circuit evidence |
| Port appears then process dies | Measure stable health, not transient listen | One port check was treated as success | Stability window, repeated heartbeat, config/API/plugin checks, circuit breaker | Detects crash loops and partial boot | Slower acceptance | Stable duration, failure count, last error |
| Concurrent Profile edit is overwritten | Prevent lost updates | Plan was not bound to current hashes | Bind hashes and lock; invalidate on mismatch | Protects user/process edits | More conflicts and replanning | Concurrent-change fault test |
| Tests or manager touch real `~/.dsh` | Protect active state during faults | Fixtures were not isolated | Disposable `DSH_HOME` and explicit temp Profile | Enables destructive failure tests safely | Fixture can drift from real state | No-access guard and cleanup evidence |

## 3. Packaging and release

| Symptom | Control objective | Root cause / why | Solution | Benefit | Cost / disadvantage | Prevention/evidence |
| --- | --- | --- | --- | --- | --- | --- |
| Git-installed TypeScript package has no runtime output | Ship executable runtime content | Git install fetches source, not registry artifacts | Commit build output or self-contained `prepare` | Fresh Git install works | Built files add churn; prepare adds lifecycle risk | Pack dry-run plus fresh Git install |
| `prepare` is blocked | Make lifecycle scripts explicit | pnpm 10 requires `allowBuilds` | Disclose exact package/script or publish prebuilt artifact | Removes hidden prompt/failure | Extra policy configuration or release artifact | Disposable install without hidden prompts |
| DSH CLI reports pnpm/path failure | Keep launcher environment deterministic | Service PATH lacks runtime directory | Add only known executable directory; keep fixed argv | Precise portable invocation | Environment discovery work | Missing-pnpm test and exact error |
| Package code changed but version did not | Keep release identity coherent | Version surfaces updated independently | Update package, README, catalog, anchor, assertions together | Easier support and rollback | Every change carries release coordination | Cross-surface consistency test |
| Repository release succeeded but local DSH still shows old UI | Separate publish from install | Profile remains pinned to old commit | Diagnose source/version; new confirmed update/restart | Preserves user control and explains drift | Two operations and confirmations | Profile dependency/manifest/UI readback |
| Local dev link is silently replaced | Preserve development source ownership | Update ignored `link:`/`file:`/workspace origin | Explicit migration plan; leave source untouched | Prevents data/work loss | Migration UX and source classification | Migration contract test |
| Marketplace metadata is untrustworthy | Establish runtime authority | Security/compatibility inferred locally | Pinned remote catalog authority; labeled offline fallback | Traceable claims and updates | Network dependence; offline data can age | Fixed-commit manifest/patch/script validation |
| Unknown security fields look reassuring | Preserve uncertainty | Missing data was guessed | Render `unknown`/`unverified` | Avoids false trust | Less polished marketplace presentation | Schema and UI tests for unknown states |
| Merge workflow fails late | Match repository governance | Branch rules/API fields were assumed | Inspect rules; allowed squash, no bypass, valid metadata | Predictable compliant release | Extra preflight and platform-specific logic | Signed commit/check readback |

## 4. Runtime and UI

| Symptom | Control objective | Root cause / why | Solution | Benefit | Cost / disadvantage | Prevention/evidence |
| --- | --- | --- | --- | --- | --- | --- |
| HTTP endpoint works but UI is absent | Verify the user-visible surface | Client loader/slot failed independently | Verify ModuleLoader, slot, and visible browser state | Catches two-sided integration failures | Requires browser/UI tooling | API and screenshot/DOM gates stay separate |
| Selected tab is hard to see | Preserve cross-theme accessibility | Subtle CSS ignored theme semantics | Official variables, roles, `aria-selected`, high contrast | Clear state and accessibility | Less bespoke styling | Light/dark preview and contract test |
| UI metadata differs from public catalog | Keep one information contract | Data sources drifted | Runtime and hosted page consume same catalog contract | Consistent trust and support | Coupling to shared schema | Compare API snapshot and public fixed commit |
| Static preview is called DSH acceptance | Preserve runtime evidence boundary | Preview bypasses Host/Profile/theme/loader | Mark E1; test inside isolated/real DSH | Honest status and real compatibility proof | More environment work | Visible Settings/slot readback E3/E4 |

## 5. External integrations

| Symptom | Control objective | Root cause / why | Solution | Benefit | Cost / disadvantage | Prevention/evidence |
| --- | --- | --- | --- | --- | --- | --- |
| Skill adapter installs but external CLI cannot work | Separate trust/failure domains | Adapter is not runtime/account/channel | Disclose prerequisites; doctor and real read separately | Precise diagnosis and status | Multiple setup and acceptance paths | Bundle, runtime, channel evidence on separate lines |
| Router rejects screenshots on fallback models | Match routing to declared capability | `input` metadata is wrong | Generator text-only; chat/reasoning text+image; preserve overrides | Correct fallback selection | Metadata migrations and more routing tests | Model migration/request-routing tests |
| Cross-provider retry corrupts requests | Keep candidate state isolated | Provider replay state survives retry | Strip private state before retry and output emission | Safer failover | Loses provider-specific continuity | Tool/reasoning/cancel failover tests |
| Mobile bridge exposes too much DSH | Bound remote control | ApiProxy was proxied wholesale | Session/control allowlist; forbid shell/files/settings/credentials/plugins | Smaller remote blast radius | Reduced flexibility | Allowlist and forbidden-action tests |
| LAN auth is mistaken for confidentiality | Protect payload and replay | Challenge authenticates but plaintext remains | HKDF directional keys, AEAD, strict sequence | Confidentiality/integrity/replay defense | Crypto state and reconnect complexity | Vectors, tamper, replay, gap tests |
| Simulator success is called mobile-ready | Match claim to real device surface | No AppID/device/network lifecycle test | Keep partial; test iOS/Android/background/network/restart | Real user evidence | Devices/accounts/time required | E5 device evidence |
| Remote relay is built before demand | Control product and threat-model scope | Cloud phase skipped LAN validation | LAN first; relay only after demand with own threat model | Faster learning and smaller early risk | Delays remote feature | Demand metric and product gate |

## 6. Tests, docs, and status

| Symptom | Control objective | Root cause / why | Solution | Benefit | Cost / disadvantage | Prevention/evidence |
| --- | --- | --- | --- | --- | --- | --- |
| Tests fail at module load after prior passes | Restore a complete reproducible environment | Peer/dev dependencies are absent | Restore from lockfile in authorized step; rerun full suite | Distinguishes environment from code failure | Dependency install time and possible network need | Never label partial run green |
| Protocol types/tests/docs disagree | Keep one versioned contract | Transport changed incompletely | Update casts, contract tests, and docs together | Prevents stale clients and misleading docs | Larger coordinated changes | Search old names before release |
| Long imports retain only metadata | Preserve useful conversation content | Dynamic budget over-trims turns | Set safe floor; reread on budget increase; report trimming | Better import fidelity | Higher token/memory cost | Long-session regression fixture |
| Test fixtures appear as user sessions | Keep discovery user-relevant | Scanner includes fixture/noise roots | Filter fixture, node_modules, probe signatures | Cleaner UI and counts | Filters may hide unusual real data | Discovery noise tests |
| Local runtime contains uncommitted code | Preserve source identity | Copy/link bypassed release | Compare installed hash to HEAD/worktree; mark unpublished | Honest provenance and debugging | Extra hash/source checks | Exact source identity report |
| README/manifest/article facts drift | Keep published claims current | Old snapshot reused | Refresh versions/counts/dates/brand at publication | Accurate communication | Repeated review work | Same-day source manifest and manual gate |
| “Verified” hides missing gates | Preserve per-surface truth | One status covers tests/install/UI/device/rollback | Report each surface and E-level | Clear next step and fewer overclaims | Longer reports | Standard verification template |
